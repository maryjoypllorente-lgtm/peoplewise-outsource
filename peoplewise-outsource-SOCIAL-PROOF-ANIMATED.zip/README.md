# Peoplewise Outsource — Single File Website

This version is intentionally self-contained.

- `index.html` contains the HTML, CSS, JavaScript, logo, and founder image.
- No installation is needed.
- No external CSS, JavaScript, or image files are required.
- Double-click `index.html` to preview it.
- For GitHub Pages, upload this `index.html` to the root of your repository.

Contact:
Email: maryjoyllorente@gmail.com
WhatsApp: +63 968 491 2139
